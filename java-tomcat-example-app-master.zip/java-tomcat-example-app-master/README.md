A simple Hello World app inspired by the steps from Heroku document "Create a Java Web Application Using Embedded Tomcat"

To run locally after cloning the repo,

1. mvn package
2. sh target/bin/webapp 

